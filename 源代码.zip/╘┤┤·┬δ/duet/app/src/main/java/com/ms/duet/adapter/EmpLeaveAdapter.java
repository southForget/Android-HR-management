package com.ms.duet.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.ms.duet.R;
import com.ms.duet.dao.EmpDao;
import com.ms.duet.dao.EmpLeaveDao;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.EmpLeave;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.Date;
import java.util.List;

public class EmpLeaveAdapter extends RecyclerView.Adapter<EmpLeaveAdapter.EmpLeaveViewHolder> {

    private Activity activity;
    private NavController controller;
    private EmpLeaveDao dao;
    private EmpDao empDao;
    private List<EmpLeave> leaves;
    public EmpLeaveAdapter(Activity activity) {
        this.activity = activity;
        controller = Navigation.findNavController(activity,R.id.fragment);
        dao=new EmpLeaveDao(activity);
        empDao = new EmpDao(activity);
        leaves=dao.findAll();
    }


    @NonNull
    @Override
    public EmpLeaveViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(parent.getContext());
        View itemView =inflater.inflate(R.layout.cell_card_leave_item,parent,false);
        return new EmpLeaveViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull EmpLeaveViewHolder holder, int position) {
        final EmpLeave leave = leaves.get(position);
        holder.tvEname.setText(leave.getEmp().getEname());
        holder.tvDname.setText(leave.getDept().getDname());
        holder.tvJname.setText(leave.getJob().getJname());
        holder.tvReason.setText(leave.getReason());
        String enter,leaves;
        enter=leave.getEnterDate().toLocaleString();
        leaves=leave.getLeaveDate().toLocaleString();
        enter=enter.substring(0,enter.lastIndexOf("日")+1);
        leaves=leaves.substring(0,leaves.lastIndexOf("日")+1);
        holder.tvEnterDate.setText(enter);
        holder.tvLeaveDate.setText(leaves);
        if (leave.getStatus()==EntityStatus.UNDEFINED.ordinal()){
            holder.tvStatus.setText("未处理！");
            holder.ibOn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder  builder = new AlertDialog.Builder(activity);
                    builder.setTitle("确认同意该申请吗?");
                    builder.setNegativeButton("确认", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            leave.setStatus(EntityStatus.ON.ordinal());
                            leave.getEmp().setStatus(EntityStatus.OFF.ordinal());
                            empDao.leave(leave.getEmp());
                            dao.updateStatus(leave);
                            notifyDataSetChanged();
                        }
                    });
                    builder.setPositiveButton("取消",null);
                    builder.show();
                }
            });
            holder.ibOff.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder  builder = new AlertDialog.Builder(activity);
                    builder.setTitle("确认拒绝该申请吗?");
                    builder.setNegativeButton("确认", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            leave.setStatus(EntityStatus.OFF.ordinal());
                            dao.updateStatus(leave);
                            notifyDataSetChanged();
                        }
                    });
                    builder.setPositiveButton("取消",null);
                    builder.show();
                }
            });
        }else if(leave.getStatus()==EntityStatus.ON.ordinal()){
            holder.tvStatus.setText("同意");
            holder.ibOn.setVisibility(View.INVISIBLE);
            holder.ibOff.setVisibility(View.INVISIBLE);
        }else{
            holder.tvStatus.setText("拒绝");
            holder.ibOn.setVisibility(View.INVISIBLE);
            holder.ibOff.setVisibility(View.INVISIBLE);
        }
        if (new Date().compareTo(leave.getLeaveDate())==1){
            leave.setStatus(EntityStatus.OFF.ordinal());
            dao.updateStatus(leave);
        }
    }

    @Override
    public int getItemCount() {
        return leaves.size();
    }

    public class EmpLeaveViewHolder extends RecyclerView.ViewHolder{
        ImageButton ibOn,ibOff;
        TextView tvEname,tvDname,tvJname,tvReason,tvStatus,tvEnterDate,tvLeaveDate;
        public EmpLeaveViewHolder(@NonNull View itemView) {
            super(itemView);
            ibOn=itemView.findViewById(R.id.ibOn);
            ibOff=itemView.findViewById(R.id.ibOff);
            tvEname=itemView.findViewById(R.id.tvEname);
            tvDname=itemView.findViewById(R.id.tvDname);
            tvJname=itemView.findViewById(R.id.tvJname);
            tvReason=itemView.findViewById(R.id.tvReason);
            tvStatus=itemView.findViewById(R.id.tvStatus);
            tvEnterDate=itemView.findViewById(R.id.tvEnterDate);
            tvLeaveDate=itemView.findViewById(R.id.tvLeaveDate);
        }
    }
}
