package com.ms.duet;


import android.app.DatePickerDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ms.duet.adapter.SpinnerDeptAdapter;
import com.ms.duet.adapter.SpinnerJobAdapter;
import com.ms.duet.dao.EmpDao;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.Job;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddEmpFragment extends Fragment {
    int year,month,day;
    Emp emp = new Emp();
    int did,jid;
    boolean gender =false;
    EditText etEname,etEmail,etPhone,etSalary;
    Spinner spDept,spJob;
    RadioGroup radioGroup;
    TextView tvJobnun,tvEnterDate,tvBirth;
    Button button;
    SpinnerDeptAdapter deptAdapter;
    SpinnerJobAdapter jobAdapter;
    EmpDao dao;
    public AddEmpFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_emp, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dao=new EmpDao(requireActivity());
        deptAdapter =new SpinnerDeptAdapter(requireActivity());
        jobAdapter =new SpinnerJobAdapter(requireActivity());
        etEname=getView().findViewById(R.id.etEname);
        etEmail=getView().findViewById(R.id.etEmail);
        etPhone=getView().findViewById(R.id.etPhone);
        etSalary=getView().findViewById(R.id.etSalary);
        tvEnterDate=getView().findViewById(R.id.tvEnterDate);
        tvBirth=getView().findViewById(R.id.tvBirth);
        radioGroup=getView().findViewById(R.id.rggender);
        tvJobnun =getView().findViewById(R.id.tvJobnun);
        button=getView().findViewById(R.id.btnAddEmp);
        spDept =getView().findViewById(R.id.spDept);
        spJob =getView().findViewById(R.id.spJob);
        emp.setJobNun(dao.getNewJobNun());
        emp.setPassword("123456");
        emp.setEid(-1);
        spDept.setAdapter(deptAdapter);
        spJob.setAdapter(jobAdapter);
        spDept.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                did= (int) deptAdapter.getItemId(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                did=0;
            }

        });
        spJob.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                jid= (int) jobAdapter.getItemId(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                jid=0;
            }
        });
        Date now=new Date();
        String  str = now.toLocaleString();
        tvEnterDate.setText(str.substring(0,str.lastIndexOf("日")+1));
        emp.setEnterDate(now);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.rbMan:
                        gender=true;
                        break;
                    case R.id.rbWoman:
                        gender=false;
                        break;
                }
            }
        });


        tvBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar =Calendar.getInstance();
                year= calendar.get(Calendar.YEAR);
                month=calendar.get(Calendar.MONTH);
                day=calendar.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dpd= new DatePickerDialog(requireContext(),DatePickerDialog.THEME_DEVICE_DEFAULT_LIGHT,
                new DatePickerDialog.OnDateSetListener(){
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        tvBirth.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                    }
                 },year,month,day);

                dpd.show();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ename  =etEname.getText().toString().trim();
                if (TextUtils.isEmpty(ename)){
                    Toast.makeText(requireActivity(),"姓名不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                String email = etEmail.getText().toString().trim();
                if (TextUtils.isEmpty(email)){
                    Toast.makeText(requireActivity(),"邮箱不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                String check = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
                Pattern regex = Pattern.compile(check);
                Matcher matcher = regex.matcher(email);
                if (!matcher.matches()){
                    Toast.makeText(requireActivity(),"邮箱格式不正确",Toast.LENGTH_SHORT).show();
                    return;
                }
                String phone = etPhone.getText().toString().trim();
                if (TextUtils.isEmpty(phone)){
                    Toast.makeText(requireActivity(),"手机号码不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }

                check = "^[1](([3][0-9])|([4][5,7,9])|([5][0-9])|([6][6])|([7][3,5,6,7,8])|([8][0-9])|([9][8,9]))[0-9]{8}$";
                regex = Pattern.compile(check);
                matcher = regex.matcher(phone);
                if (!matcher.matches()){
                    Toast.makeText(requireActivity(),"手机号码格式不正确",Toast.LENGTH_SHORT).show();
                    return;
                }
                String strSalary = etSalary.getText().toString().trim();
                if (TextUtils.isEmpty(strSalary)){
                    Toast.makeText(requireActivity(),"薪资不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                float salary =Float.valueOf(strSalary);
                String strBirth = tvBirth.getText().toString().trim();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Calendar cr = Calendar.getInstance();
                cr.add(Calendar.YEAR,-22);
                Date min = cr.getTime();
                cr.add(Calendar.YEAR,-18);
                Date max =cr.getTime();
                try {
                    Date birth = sdf.parse(strBirth);
                    if (birth.compareTo(min)==1){
                        Toast.makeText(requireActivity(),"出生日期应大于"+min.toLocaleString(),Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (birth.compareTo(max)==-1){
                        Toast.makeText(requireActivity(),"出生日期应小于"+max.toLocaleString(),Toast.LENGTH_SHORT).show();
                        return;
                    }
                    emp.setBirth(birth);
                } catch (ParseException e) {
                    Toast.makeText(requireActivity(),"时间格式不正确！",Toast.LENGTH_SHORT).show();
                    return;
                }
                Dept dept=  new Dept();
                dept.setDid(did);
                Job job = new Job();
                job.setJid(jid);
                emp.setDept(dept);
                emp.setJob(job);
                emp.setEname(ename);
                emp.setEmail(email);
                emp.setPhone(phone);
                emp.setSalary(salary);
                emp.setStatus(EntityStatus.RESETPASSWORD.ordinal());
//                System.out.println(emp);
                dao.insert(emp);
                Toast.makeText(requireActivity(),"入职成功！工号："+emp.getJobNun(),Toast.LENGTH_SHORT).show();
                Navigation.findNavController(requireActivity(),R.id.fragment).navigateUp();
            }
        });
    }
}
