package com.ms.duet;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ms.duet.adapter.EmpChangeAdapter;
import com.ms.duet.adapter.EmpLeaveAdapter;
import com.ms.duet.entity.EmpChange;


/**
 * A simple {@link Fragment} subclass.
 */
public class AppManagFragment extends Fragment {

    RecyclerView rcLeave,rcChange;
    EmpLeaveAdapter leaveAdapter;
    EmpChangeAdapter changeAdapter;
    public AppManagFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_app_manag, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        leaveAdapter = new EmpLeaveAdapter(requireActivity());
        changeAdapter = new EmpChangeAdapter(requireActivity());
        rcLeave=getView().findViewById(R.id.rcLeave);
        rcChange=getView().findViewById(R.id.rcChange);
        rcLeave.setLayoutManager(new LinearLayoutManager(getContext()));
        rcLeave.setAdapter(leaveAdapter);
        rcChange.setLayoutManager(new LinearLayoutManager(getContext()));
        rcChange.setAdapter(changeAdapter);
    }
}
