package com.ms.duet;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class AdminFragment extends Fragment {

    Button empManag;
    Button deptManag;
    Button jobManag;
    Button appManag;
    NavController controller;


    public AdminFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_admin, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        controller = Navigation.findNavController(getActivity(),R.id.fragment);
        View  adminView=getView();
        empManag =adminView.findViewById(R.id.btnEmpManag);
        deptManag =adminView.findViewById(R.id.btnDeptManag);
        jobManag =adminView.findViewById(R.id.btnJobManag);
        appManag =adminView.findViewById(R.id.btnAppManag);

        empManag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controller.navigate(R.id.action_adminFragment_to_empManagFragment);
            }
        });

        deptManag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controller.navigate(R.id.action_adminFragment_to_deptManagFragment);
            }
        });

        jobManag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controller.navigate(R.id.action_adminFragment_to_jobManagFragment);
            }
        });

        appManag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controller.navigate(R.id.action_adminFragment_to_appManagFragment);
            }
        });
    }
}
