package com.ms.duet.adapter;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.ms.duet.R;
import com.ms.duet.dao.DeptDao;
import com.ms.duet.entity.Dept;

import java.util.List;

public class SpinnerDeptAdapter extends BaseAdapter {
    Activity activity;
    DeptDao dao;
    List<Dept> depts;


    public int getPositionById(int id){
        Object[] objects = depts.toArray();
        for (int i = 0; i <objects.length ; i++) {
            Dept item = (Dept) objects[i];
            if (item.getDid()==id)
                return i;
        }
        return 0;
    }

    public SpinnerDeptAdapter(Activity activity) {
        this.activity = activity;
        dao= new DeptDao(activity);
        depts= dao.findAllByStatusOn();
    }

    @Override
    public int getCount() {
        return depts.size();
    }

    @Override
    public Object getItem(int position) {
        return depts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return depts.get(position).getDid();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = convertView!=null?convertView:View.inflate(activity, R.layout.cell_spinner_item,null);
        Dept dept = (Dept) getItem(position);
        TextView textView = convertView.findViewById(R.id.tvSpItem);
        textView.setText(dept.getDname());
        return convertView;
    }
}
