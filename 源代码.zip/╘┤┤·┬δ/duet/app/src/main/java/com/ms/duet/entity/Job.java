package com.ms.duet.entity;



public class Job {
    private int jid;
    private String jname;
    private String jdes;
    private int status;

    @Override
    public String toString() {
        return "Job{" +
                "jid=" + jid +
                ", jname='" + jname + '\'' +
                ", jdes='" + jdes + '\'' +
                ", status=" + status +
                '}';
    }

    public int getJid() {
        return jid;
    }

    public void setJid(int jid) {
        this.jid = jid;
    }

    public String getJname() {
        return jname;
    }

    public void setJname(String jname) {
        this.jname = jname;
    }

    public String getJdes() {
        return jdes;
    }

    public void setJdes(String jdes) {
        this.jdes = jdes;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
