package com.ms.duet.entity;



import java.util.Date;

public class EmpLeave {
    private int elid;
    private Emp emp;
    private Dept dept;
    private Job job;
    private Date enterDate;
    private Date leaveDate;
    private String reason;
    private int status;


    public int getElid() {
        return elid;
    }

    public void setElid(int elid) {
        this.elid = elid;
    }

    public Emp getEmp() {
        return emp;
    }

    public void setEmp(Emp emp) {
        this.emp = emp;
    }

    public Dept getDept() {
        return dept;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public Date getEnterDate() {
        return enterDate;
    }

    public void setEnterDate(Date enterDate) {
        this.enterDate = enterDate;
    }

    public Date getLeaveDate() {
        return leaveDate;
    }

    public void setLeaveDate(Date leaveDate) {
        this.leaveDate = leaveDate;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "EmpLeave{" +
                "elid=" + elid +
                ", emp=" + emp +
                ", dept=" + dept +
                ", job=" + job +
                ", enterDate=" + enterDate +
                ", leaveDate=" + leaveDate +
                ", reason='" + reason + '\'' +
                ", status=" + status +
                '}';
    }
}
