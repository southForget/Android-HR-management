package com.ms.duet;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ms.duet.dao.DeptDao;
import com.ms.duet.entity.Dept;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateDeptFragment extends Fragment {

    private DeptDao dao;
    EditText etDname;
    EditText etDdes;
    Button btnUpdate;

    public UpdateDeptFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_update_dept, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        int did =getArguments().getInt("did");
        dao= new DeptDao(requireActivity());
        final Dept dept =dao.findDeptByDid(did);
        etDname =getView().findViewById(R.id.etDname);
        etDdes=getView().findViewById(R.id.etDdes);
        btnUpdate=getView().findViewById(R.id.btnUpdate);
        etDname.setText(dept.getDname());
        etDdes.setText(dept.getDdes());
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dname = etDname.getText().toString().trim();
                String ddes =etDdes.getText().toString().trim();
                if (TextUtils.isEmpty(dname)|| TextUtils.isEmpty(ddes)){
                    Toast.makeText(requireActivity(),"部门名称或部门描述不能为空！",Toast.LENGTH_SHORT).show();
                    return;
                }
                dept.setDname(dname);
                dept.setDdes(ddes);
                dao.update(dept);
                Toast.makeText(requireActivity(),"修改成功！",Toast.LENGTH_SHORT).show();
                Navigation.findNavController(getActivity(),R.id.fragment).navigateUp();
            }
        });
    }
}
