package com.ms.duet;


import android.app.DatePickerDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ms.duet.adapter.SpinnerDeptAdapter;
import com.ms.duet.adapter.SpinnerJobAdapter;
import com.ms.duet.dao.EmpDao;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.Job;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateEmpFragment extends Fragment {
    int did,jid,year,month,day;
    boolean gender =false;
    EditText etEname,etEmail,etPhone,etSalary;
    Spinner spDept,spJob;
    RadioGroup radioGroup;
    RadioButton man,woman;
    TextView tvJobnun,tvEnterDate,tvBirth;
    Button button;
    SpinnerDeptAdapter deptAdapter;
    SpinnerJobAdapter jobAdapter;
    EmpDao dao;



    public UpdateEmpFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_update_emp, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        int eid = getArguments().getInt("eid");
        dao= new EmpDao(requireActivity());
        final Emp emp =dao.findEmpByEid(eid);
        deptAdapter =new SpinnerDeptAdapter(requireActivity());
        jobAdapter =new SpinnerJobAdapter(requireActivity());
        etEname=getView().findViewById(R.id.etEname);
        etEmail=getView().findViewById(R.id.etEmail);
        etPhone=getView().findViewById(R.id.etPhone);
        etSalary=getView().findViewById(R.id.etSalary);
        tvEnterDate=getView().findViewById(R.id.tvEnterDate);
        tvBirth=getView().findViewById(R.id.tvBirth);
        radioGroup=getView().findViewById(R.id.rggender);
        man=getView().findViewById(R.id.rbMan);
        woman=getView().findViewById(R.id.rbWoman);
        tvJobnun =getView().findViewById(R.id.tvJobnun);
        button=getView().findViewById(R.id.btnUpdateEmp);
        spDept =getView().findViewById(R.id.spDept);
        spJob =getView().findViewById(R.id.spJob);
        spDept.setAdapter(deptAdapter);
        spJob.setAdapter(jobAdapter);
        int defDP=deptAdapter.getPositionById(emp.getDept().getDid());
        spDept.setSelection(defDP,true);
        int defJP = jobAdapter.getPositionById(emp.getJob().getJid());
        spJob.setSelection(defJP,true);
        jid=emp.getJob().getJid();
        did=emp.getDept().getDid();
        spDept.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                did= (int) deptAdapter.getItemId(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });
        spJob.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                jid= (int) jobAdapter.getItemId(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.rbMan:
                        gender=true;
                        break;
                    case R.id.rbWoman:
                        gender=false;
                        break;
                }
            }
        });

        tvJobnun.setText(emp.getJobNun());
        etEname.setText(emp.getEname());
        if (emp.getGender()){
            man.setChecked(true);
            woman.setChecked(false);
        }else{
            man.setChecked(false);
            woman.setChecked(true);
        }
        etSalary.setText(String.valueOf(emp.getSalary()));
        String str = emp.getBirth().toLocaleString();
        str=str.substring(0,str.lastIndexOf("日"));
        String syear =str.substring(0,str.lastIndexOf("年"));
        String smonth=str.substring(str.lastIndexOf("年")+1,str.lastIndexOf("月"));
        String sday = str.substring(str.lastIndexOf("月")+1);
        this.year = Integer.parseInt(syear);
        this.month = Integer.parseInt(smonth);
        this.day = Integer.parseInt(sday);
        tvBirth.setText(String.format("%s-%s-%s",year,month,day));
        String strenter = emp.getEnterDate().toLocaleString();
        tvEnterDate.setText(strenter.substring(0,strenter.lastIndexOf("日")+1));
        etPhone.setText(emp.getPhone());
        etEmail.setText(emp.getEmail());

        tvBirth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog dpd= new DatePickerDialog(requireContext(),DatePickerDialog.THEME_DEVICE_DEFAULT_LIGHT,
                        new DatePickerDialog.OnDateSetListener(){
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                tvBirth.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                            }
                        },year,month,day);

                dpd.show();
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ename  =etEname.getText().toString().trim();
                if (TextUtils.isEmpty(ename)){
                    Toast.makeText(requireActivity(),"姓名不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                String email = etEmail.getText().toString().trim();
                if (TextUtils.isEmpty(email)){
                    Toast.makeText(requireActivity(),"邮箱不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                String check = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
                Pattern regex = Pattern.compile(check);
                Matcher matcher = regex.matcher(email);
                if (!matcher.matches()){
                    Toast.makeText(requireActivity(),"邮箱格式不正确",Toast.LENGTH_SHORT).show();
                    return;
                }
                String phone = etPhone.getText().toString().trim();
                if (TextUtils.isEmpty(phone)){
                    Toast.makeText(requireActivity(),"手机号码不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }

                check = "^[1](([3][0-9])|([4][5,7,9])|([5][0-9])|([6][6])|([7][3,5,6,7,8])|([8][0-9])|([9][8,9]))[0-9]{8}$";
                regex = Pattern.compile(check);
                matcher = regex.matcher(phone);
                if (!matcher.matches()){
                    Toast.makeText(requireActivity(),"手机号码格式不正确",Toast.LENGTH_SHORT).show();
                    return;
                }
                String strSalary = etSalary.getText().toString().trim();
                if (TextUtils.isEmpty(strSalary)){
                    Toast.makeText(requireActivity(),"薪资不能为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                float salary =Float.valueOf(strSalary);
                String strBirth = tvBirth.getText().toString().trim();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Calendar cr = Calendar.getInstance();
                cr.add(Calendar.YEAR,-22);
                Date min = cr.getTime();
                cr.add(Calendar.YEAR,-18);
                Date max =cr.getTime();
                try {
                    Date birth = sdf.parse(strBirth);
                    if (birth.compareTo(min)==1){
                        Toast.makeText(requireActivity(),"出生日期应大于"+min.toLocaleString(),Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (birth.compareTo(max)==-1){
                        Toast.makeText(requireActivity(),"出生日期应小于"+max.toLocaleString(),Toast.LENGTH_SHORT).show();
                        return;
                    }
                    emp.setBirth(birth);
                } catch (ParseException e) {
                    Toast.makeText(requireActivity(),"时间格式不正确！",Toast.LENGTH_SHORT).show();
                    return;
                }
                Dept dept=  new Dept();
                dept.setDid(did);
                Job job = new Job();
                job.setJid(jid);
                emp.setDept(dept);
                emp.setJob(job);
                emp.setGender(gender);
                emp.setEname(ename);
                emp.setEmail(email);
                emp.setPhone(phone);
                emp.setSalary(salary);
                dao.update(emp);
                Toast.makeText(requireActivity(),"保存成功！",Toast.LENGTH_SHORT).show();
                Navigation.findNavController(requireActivity(),R.id.fragment).navigateUp();
            }
        });
    }
}
