package com.ms.duet.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ms.duet.dababase.DuetDataBase;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.EmpChange;
import com.ms.duet.entity.Job;

import java.util.ArrayList;
import java.util.List;

public class EmpChangeDao {
    private DuetDataBase database;
    private DeptDao deptDao;
    private JobDao jobDao;
    private EmpDao empDao;
    public EmpChangeDao(Context context) {
        this.database = new DuetDataBase(context,"iHr.db",null,1);
        deptDao = new DeptDao(context);
        jobDao= new JobDao(context);
        empDao = new EmpDao(context);
    }

    public void insert(EmpChange change) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("eid",change.getEmp().getEid());
        values.put("oldDid",change.getOldDept().getDid());
        values.put("newDid",change.getNewDept().getDid());
        values.put("oldJid",change.getOldJob().getJid());
        values.put("newJid",change.getNewJob().getJid());
        values.put("reason",change.getReason());
        values.put("status",change.getStatus());
        database.insert("empChange",null,values);
    }

    public List<EmpChange> findAll() {
        SQLiteDatabase database = this.database.getReadableDatabase();
        List<EmpChange> changes = new  ArrayList();
        Cursor cursor = database.query("empChange",null,null,null,null,null,null);
        if (cursor!=null&& cursor.getCount()>0){
            while (cursor.moveToNext()){
                int ecid = cursor.getInt(cursor.getColumnIndex("ecid"));
                int eid = cursor.getInt(cursor.getColumnIndex("eid"));
                int oldDid = cursor.getInt(cursor.getColumnIndex("oldDid"));
                int newDid = cursor.getInt(cursor.getColumnIndex("newDid"));
                int oldJid = cursor.getInt(cursor.getColumnIndex("oldJid"));
                int newJid = cursor.getInt(cursor.getColumnIndex("newJid"));
                String reason = cursor.getString(cursor.getColumnIndex("reason"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                Emp emp = empDao.findEmpByEid(eid);
                Dept oldD = deptDao.findDeptByDid(oldDid);
                Dept newD = deptDao.findDeptByDid(newDid);
                Job oldJ = jobDao.findJobByjid(oldJid);
                Job newJ = jobDao.findJobByjid(newJid);
                EmpChange change = new EmpChange();
                change.setOldDept(oldD);
                change.setOldJob(oldJ);
                change.setNewDept(newD);
                change.setNewJob(newJ);
                change.setEmp(emp);
                change.setEcid(ecid);
                change.setReason(reason);
                change.setStatus(status);
                changes.add(change);
            }
            cursor.close();
        }
        database.close();
        return changes;
    }

    public void updateStatus(EmpChange change) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status",change.getStatus());
        database.update("empChange",values,"ecid=?",new String[]{String.valueOf(change.getEcid())});
        database.close();
    }
}
