package com.ms.duet.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ms.duet.dababase.DuetDataBase;
import com.ms.duet.entity.Job;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.ArrayList;
import java.util.List;

public class JobDao {
    private DuetDataBase database;

    public JobDao(Context context) {
        this.database = new DuetDataBase(context,"iHr.db",null,1);
    }

    public List<Job> findAll(){
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("job", null, null, null, null, null, null);
        List<Job> jobs =new ArrayList<>();
        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                int jid=cursor.getInt(cursor.getColumnIndex("jid"));
                String jname  = cursor.getString(cursor.getColumnIndex("jname"));
                String jdes = cursor.getString(cursor.getColumnIndex("jdes"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                Job job =  new Job();
                job.setJid(jid);
                job.setJname(jname);
                job.setJdes(jdes);
                job.setStatus(status);
                jobs.add(job);
            }
        }
        cursor.close();
        database.close();
        return jobs;
    }

    public void insert(Job job) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values  = new ContentValues();
        values.put("jname",job.getJname());
        values.put("jdes",job.getJdes());
        values.put("status",job.getStatus());
        int jid = (int) database.insert("job",null,values);
        job.setJid(jid);
        database.close();
    }

    public void update(Job job){
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues  values =new ContentValues();
        values.put("jname",job.getJname());
        values.put("jdes",job.getJdes());
        values.put("status",job.getStatus());
        database.update("job",values,"jid=?",new String[]{String.valueOf(job.getJid())});
        database.close();
    }

    public int getCountByJid(int jid){
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("emp", new String[]{"count(*) as num"}, "jid=? and status = ?", new String[]{String.valueOf(jid),String.valueOf(EntityStatus.ON.ordinal())}, null, null, null);
        int num=0;
        if (cursor!=null & cursor.getCount()>0){
            cursor.moveToNext();
            num = cursor.getInt(cursor.getColumnIndex("num"));
        }
        cursor.close();
        database.close();
        return num;
    }


    public Job isExitByJname(Job job){
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("job", null, "jname=?", new String[]{job.getJname()}, null, null, null);
        Job result = new Job();
        result.setStatus(EntityStatus.UNDEFINED.ordinal());
        if (cursor!=null && cursor.getCount()>0){
            if (cursor.moveToNext()){
                int jid=cursor.getInt(cursor.getColumnIndex("jid"));
                String jname  = cursor.getString(cursor.getColumnIndex("jname"));
                String jdes = cursor.getString(cursor.getColumnIndex("jdes"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                result.setJid(jid);
                result.setJname(jname);
                result.setJdes(jdes);
                result.setStatus(status);
            }
            cursor.close();
        }
        database.close();
        return result;
    }

    public Job findJobByjid(int jid) {
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("job", null, "jid=?", new String[]{String.valueOf(jid)}, null, null, null);
        Job result = new Job();
        result.setStatus(EntityStatus.UNDEFINED.ordinal());
        if (cursor!=null && cursor.getCount()>0){
            if (cursor.moveToNext()){
                String jname  = cursor.getString(cursor.getColumnIndex("jname"));
                String jdes = cursor.getString(cursor.getColumnIndex("jdes"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                result.setJid(jid);
                result.setJname(jname);
                result.setJdes(jdes);
                result.setStatus(status);
            }
            cursor.close();
        }
        database.close();
        return result;
    }

    public List<Job> findAllByStatusOn() {
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("job", null, "`status`=?", new String[]{ String.valueOf(EntityStatus.ON.ordinal())}, null, null, null);
        List<Job> jobs =new ArrayList<>();
        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                int jid=cursor.getInt(cursor.getColumnIndex("jid"));
                String jname  = cursor.getString(cursor.getColumnIndex("jname"));
                String jdes = cursor.getString(cursor.getColumnIndex("jdes"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                Job job = new Job();
                job.setJid(jid);
                job.setJname(jname);
                job.setJdes(jdes);
                job.setStatus(status);
                jobs.add(job);
            }
        }
        cursor.close();
        database.close();
        return jobs;
    }
}
