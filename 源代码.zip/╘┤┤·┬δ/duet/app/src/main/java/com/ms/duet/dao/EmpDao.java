package com.ms.duet.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ms.duet.dababase.DuetDataBase;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.Job;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EmpDao {
    private DuetDataBase database;

    public EmpDao(Context context) {
        this.database = new DuetDataBase(context,"iHr.db",null,1);
    }

    public List<Emp> findAll(String searchKey) {
        SQLiteDatabase database = this.database.getReadableDatabase();
        List<Emp> emps = new ArrayList<>();
        searchKey="%"+searchKey+"%";
        String[] columns =new String[]{"eid","ename","jobNun","e.did","e.jid","dname","jname","enterDate","salary","gender","birth","phone","email","e.status"};
        Cursor cursor = database.query("emp e left join dept d on e.did =d.did left join job j on e.jid=j.jid" , columns, "ename like ? or jobNun like ?", new String[]{searchKey, searchKey}, null, null, null);
        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                Emp emp = new Emp();
                int eid =cursor.getInt(cursor.getColumnIndex("eid"));
                String ename =cursor.getString(cursor.getColumnIndex("ename"));
                String jobNun =cursor.getString(cursor.getColumnIndex("jobNun"));
                int did = cursor.getInt(cursor.getColumnIndex("did"));
                String dname =cursor.getString(cursor.getColumnIndex("dname"));
                int jid = cursor.getInt(cursor.getColumnIndex("jid"));
                String jname =cursor.getString(cursor.getColumnIndex("jname"));
                Long enterDate =cursor.getLong(cursor.getColumnIndex("enterDate"));
                float salary =cursor.getFloat(cursor.getColumnIndex("salary"));
                Boolean gender  = cursor.getInt(cursor.getColumnIndex("gender"))==1;
                Long birth =cursor.getLong(cursor.getColumnIndex("birth"));
                String phone =cursor.getString(cursor.getColumnIndex("phone"));
                String email =cursor.getString(cursor.getColumnIndex("email"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                Dept dept = new Dept();
                dept.setDid(did);
                dept.setDname(dname);
                Job job = new Job();
                job.setJid(jid);
                job.setJname(jname);
                emp.setEid(eid);
                emp.setEname(ename);
                emp.setJobNun(jobNun);
                emp.setDept(dept);
                emp.setJob(job);
                emp.setEnterDate(new Date(enterDate));
                emp.setSalary(salary);
                emp.setGender(gender);
                emp.setBirth(new Date(birth));
                emp.setPhone(phone);
                emp.setEmail(email);
                emp.setStatus(status);
                emps.add(emp);
            }
            cursor.close();
        }
        database.close();
        return emps;
    }

    public void update(Emp emp) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("did",emp.getDept().getDid());
        values.put("jid",emp.getJob().getJid());
        values.put("enterDate",emp.getEnterDate().getTime());
        values.put("salary",emp.getSalary());
        values.put("phone",emp.getPhone());
        values.put("ename",emp.getEname());
        values.put("gender",emp.getGender());
        values.put("birth",emp.getBirth().getTime());
        values.put("email",emp.getEmail());
        values.put("status",emp.getStatus());
        database.update("emp",values,"eid=?",new String[]{String.valueOf(emp.getEid())});
        database.close();
    }

    public void resetPassword(Emp emp){
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("password","123456");
        values.put("status", EntityStatus.RESETPASSWORD.ordinal());
        database.update("emp",values,"eid=?",new String[]{String.valueOf(emp.getEid())});
        database.close();
    }

    public void updatePassword(Emp emp) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("password",emp.getPassword());
        values.put("status",EntityStatus.ON.ordinal());
        database.update("emp",values,"eid=?",new String[]{String.valueOf(emp.getEid())});
        database.close();
    }

    public void insert(Emp emp){
        SQLiteDatabase writableDatabase = database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("jobNun",emp.getJobNun());
        values.put("password",emp.getPassword());
        values.put("did",emp.getDept().getDid());
        values.put("jid",emp.getJob().getJid());
        values.put("enterDate",emp.getEnterDate().getTime());
        values.put("salary",emp.getSalary());
        values.put("phone",emp.getPhone());
        values.put("ename",emp.getEname());
        values.put("gender",emp.getGender());
        values.put("birth",emp.getBirth().getTime());
        values.put("email",emp.getEmail());
        values.put("status",emp.getStatus());
        writableDatabase.insert("emp",null,values);
        writableDatabase.close();
    }

    public String getNewJobNun() {
        SQLiteDatabase database = this.database.getReadableDatabase();
        int count =0;
        Cursor cursor = database.query("emp", new String[]{"count(*) as num"}, null, null, null, null, null);
        if (cursor!=null&& cursor.getCount()>0){
            if (cursor.moveToNext()){
                count=cursor.getInt(cursor.getColumnIndex("num"));
                cursor.close();
            }
        }
        count++;
        Date now =new Date();
        String jobNun=  String.valueOf((now.getYear()+1900)%1000)+String.format("%02d",now.getMonth()+1)+String.format("%06d",count);
        database.close();
        return jobNun;
    }

    public Emp findEmpByEid(int eid) {
        SQLiteDatabase database = this.database.getReadableDatabase();
        String[] columns =new String[]{"eid","ename","jobNun","e.did","e.jid","dname","jname","enterDate","salary","gender","birth","phone","email","e.status"};
        Cursor cursor = database.query("emp e left join dept d on e.did =d.did left join job j on e.jid=j.jid" , columns, "eid=?", new String[]{String.valueOf(eid)}, null, null, null);
        Emp emp = new Emp();
        emp.setEid(-1);
        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                eid =cursor.getInt(cursor.getColumnIndex("eid"));
                String ename =cursor.getString(cursor.getColumnIndex("ename"));
                String jobNun =cursor.getString(cursor.getColumnIndex("jobNun"));
                int did = cursor.getInt(cursor.getColumnIndex("did"));
                String dname =cursor.getString(cursor.getColumnIndex("dname"));
                int jid = cursor.getInt(cursor.getColumnIndex("jid"));
                String jname =cursor.getString(cursor.getColumnIndex("jname"));
                Long enterDate =cursor.getLong(cursor.getColumnIndex("enterDate"));
                float salary =cursor.getFloat(cursor.getColumnIndex("salary"));
                Boolean gender  = cursor.getInt(cursor.getColumnIndex("gender"))==1;
                Long birth =cursor.getLong(cursor.getColumnIndex("birth"));
                String phone =cursor.getString(cursor.getColumnIndex("phone"));
                String email =cursor.getString(cursor.getColumnIndex("email"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                Dept dept = new Dept();
                dept.setDid(did);
                dept.setDname(dname);
                Job job = new Job();
                job.setJid(jid);
                job.setJname(jname);
                emp.setEid(eid);
                emp.setEname(ename);
                emp.setJobNun(jobNun);
                emp.setDept(dept);
                emp.setJob(job);
                emp.setEnterDate(new Date(enterDate));
                emp.setSalary(salary);
                emp.setGender(gender);
                emp.setBirth(new Date(birth));
                emp.setPhone(phone);
                emp.setEmail(email);
                emp.setStatus(status);
            }
            cursor.close();
        }
        database.close();
        return emp;
    }

    public Emp login(Emp emp) {
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("emp" , null, "jobNun = ? and password = ?", new String[]{emp.getJobNun(),emp.getPassword() }, null, null, null);
        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                int eid =cursor.getInt(cursor.getColumnIndex("eid"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                emp.setEid(eid);
                emp.setStatus(status);
            }
            cursor.close();
        }
        database.close();
        return emp;
    }

    public void updateConcat(Emp emp) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("phone",emp.getPhone());
        values.put("email",emp.getEmail());
        database.update("emp",values,"eid=?",new String[]{String.valueOf(emp.getEid())});
        database.close();
    }

    public void leave(Emp emp) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status",emp.getStatus());
        database.update("emp",values,"eid=?",new String[]{String.valueOf(emp.getEid())});
        database.close();
    }
}
