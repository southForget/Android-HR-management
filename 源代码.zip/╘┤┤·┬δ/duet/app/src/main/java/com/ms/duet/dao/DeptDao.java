package com.ms.duet.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


import com.ms.duet.dababase.DuetDataBase;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.ArrayList;
import java.util.List;

public class DeptDao {
    private DuetDataBase database;

    public DeptDao(Context context) {
        this.database = new DuetDataBase(context,"iHr.db",null,1);
    }

    public List<Dept> findAll(){
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("dept", null, null, null, null, null, null);
        List<Dept> depts =new ArrayList<>();
        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                int did=cursor.getInt(cursor.getColumnIndex("did"));
                String dname  = cursor.getString(cursor.getColumnIndex("dname"));
                String ddes = cursor.getString(cursor.getColumnIndex("ddes"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                Dept dept = new Dept();
                dept.setDid(did);
                dept.setDname(dname);
                dept.setDdes(ddes);
                dept.setStatus(status);
                depts.add(dept);
            }
        }
        cursor.close();
        database.close();
        return depts;
    }

    public void insert(Dept dept) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values  = new ContentValues();
        values.put("dname",dept.getDname());
        values.put("ddes",dept.getDdes());
        values.put("status",dept.getStatus());
        int did = (int) database.insert("dept",null,values);
        dept.setDid(did);
        database.close();
    }

    public void update(Dept dept){
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues  values =new ContentValues();
        values.put("dname",dept.getDname());
        values.put("ddes",dept.getDdes());
        values.put("status",dept.getStatus());
        database.update("dept",values,"did=?",new String[]{String.valueOf(dept.getDid())});
        database.close();
    }


    public Dept isExitByDname(Dept dept){
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("dept", null, "dname=?", new String[]{dept.getDname()}, null, null, null);
        Dept result = new Dept();
        result.setStatus(EntityStatus.UNDEFINED.ordinal());
        if (cursor!=null && cursor.getCount()>0){
            if (cursor.moveToNext()){
                int did=cursor.getInt(cursor.getColumnIndex("did"));
                String dname  = cursor.getString(cursor.getColumnIndex("dname"));
                String ddes = cursor.getString(cursor.getColumnIndex("ddes"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                result.setDid(did);
                result.setDname(dname);
                result.setDdes(ddes);
                result.setStatus(status);
            }
            cursor.close();
        }
        database.close();
        return result;
    }

    public Dept findDeptByDid(int did) {
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("dept", null, "did=?", new String[]{String.valueOf(did)}, null, null, null);
        Dept result = new Dept();
        result.setStatus(EntityStatus.UNDEFINED.ordinal());
        if (cursor!=null && cursor.getCount()>0){
            if (cursor.moveToNext()){
                String dname  = cursor.getString(cursor.getColumnIndex("dname"));
                String ddes = cursor.getString(cursor.getColumnIndex("ddes"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                result.setDid(did);
                result.setDname(dname);
                result.setDdes(ddes);
                result.setStatus(status);
            }
            cursor.close();
        }
        database.close();
        return result;
    }

    public int getCountByDid(int did){
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("emp", new String[]{"count(*) as num"}, "did=? and status = ?", new String[]{String.valueOf(did),String.valueOf(EntityStatus.ON.ordinal())}, null, null, null);
        int num=0;
        if (cursor!=null & cursor.getCount()>0){
            cursor.moveToNext();
            num = cursor.getInt(cursor.getColumnIndex("num"));
            cursor.close();
        }
        database.close();
        return num;
    }

    public List<Dept> findAllByStatusOn() {
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("dept", null, "`status`=?", new String[]{ String.valueOf(EntityStatus.ON.ordinal())}, null, null, null);
        List<Dept> depts =new ArrayList<>();
        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                int did=cursor.getInt(cursor.getColumnIndex("did"));
                String dname  = cursor.getString(cursor.getColumnIndex("dname"));
                String ddes = cursor.getString(cursor.getColumnIndex("ddes"));
                int status = cursor.getInt(cursor.getColumnIndex("status"));
                Dept dept = new Dept();
                dept.setDid(did);
                dept.setDname(dname);
                dept.setDdes(ddes);
                dept.setStatus(status);
                depts.add(dept);
            }
        }
        cursor.close();
        database.close();
        return depts;
    }
}
