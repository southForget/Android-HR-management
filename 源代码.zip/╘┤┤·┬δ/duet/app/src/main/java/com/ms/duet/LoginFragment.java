package com.ms.duet;


import android.app.DatePickerDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.ms.duet.dao.AdminDao;
import com.ms.duet.dao.EmpDao;
import com.ms.duet.entity.Admin;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.Date;


/**
 * A simple {@link Fragment} subclass.
 */
public class LoginFragment extends Fragment {

    byte loginModel = 0;
    NavController controller;
    EditText etAccount;
    EditText etPwd;
    AdminDao adminDao;
    EmpDao empDao;
    public LoginFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false);
    }



    public void adminLogin(String account,String pwd){
        Admin admin = new Admin();
        admin.setAccount(account);
        admin.setPassword(pwd);
        admin = adminDao.login(admin);
        if (admin.getAid()==0){
            Toast.makeText(getContext(),"用户名或密码不正确，请重试！",Toast.LENGTH_SHORT).show();
            return;
        }
        etAccount.setText("");
        etPwd.setText("");
        controller.navigate(R.id.action_loginFragment_to_adminFragment);
    }
    public void empLogin(String account,String pwd){
        Emp emp = new Emp();
        emp.setJobNun(account);
        emp.setPassword(pwd);
        emp= empDao.login(emp);
        Bundle bundle = new Bundle();
        bundle.putInt("eid",emp.getEid());
        if (emp.getEid()==0){
            Toast.makeText(getContext(),"用户名或密码不正确，请重试！",Toast.LENGTH_SHORT).show();
            return;
        }
        if (emp.getStatus()== EntityStatus.OFF.ordinal()){
            Toast.makeText(getContext(),"该账户不可用！",Toast.LENGTH_SHORT).show();
            return;
        }else if (emp.getStatus()== EntityStatus.RESETPASSWORD.ordinal()){
            controller.navigate(R.id.action_loginFragment_to_updateEmpPasswordFragment,bundle);
            return;
        }
        etAccount.setText("");
        etPwd.setText("");
        controller.navigate(R.id.action_loginFragment_to_empFragment,bundle);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        adminDao =  new AdminDao(requireActivity());
        empDao = new EmpDao(requireActivity());
        controller = Navigation.findNavController(getActivity(),R.id.fragment);
        Button btnlogin =getView().findViewById(R.id.btnLogin);
        etAccount  =getView().findViewById(R.id.etDname);
        etPwd  =getView().findViewById(R.id.etPwd);
        final RadioGroup radioGroup =getView().findViewById(R.id.rbg);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.rbAdmin:
                        loginModel=1;
                        break;
                    case R.id.rbEmp:
                        loginModel=-1;
                        break;
                }
            }
        });
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String account = etAccount.getText().toString().trim();
                String pwd  =etPwd.getText().toString().trim();
                if (TextUtils.isEmpty(account)){
                    Toast.makeText(getActivity(),"账户不可以为空！",Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(pwd)){
                    Toast.makeText(getActivity(),"密码不可以为空！",Toast.LENGTH_SHORT).show();
                    return;
                }
                switch (loginModel){
                    case 0:
                        Toast.makeText(getActivity(),"请选择登录角色！",Toast.LENGTH_SHORT).show();
                        break;
                    case 1:
                        adminLogin(account,pwd);
                        break;
                    case -1:
                        empLogin(account,pwd);
                        break;
                }
            }
        });



    }
}
