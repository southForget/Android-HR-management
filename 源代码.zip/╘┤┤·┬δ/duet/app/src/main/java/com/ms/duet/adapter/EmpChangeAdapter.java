package com.ms.duet.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.ms.duet.R;
import com.ms.duet.dao.EmpChangeDao;
import com.ms.duet.dao.EmpDao;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.EmpChange;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.List;

public class EmpChangeAdapter extends RecyclerView.Adapter<EmpChangeAdapter.EmpChangeViewHolder> {

    private Activity activity;
    private NavController controller;
    private List<EmpChange> changes;
    private EmpChangeDao dao;
    private  EmpDao empDao;
    public EmpChangeAdapter(Activity activity) {
        this.activity = activity;
        dao= new EmpChangeDao(activity);
        empDao =new EmpDao(activity);
        changes=dao.findAll();
        controller = Navigation.findNavController(activity,R.id.fragment);
    }

    @NonNull
    @Override
    public EmpChangeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(parent.getContext());
        View itemView =inflater.inflate(R.layout.cell_card_change_item,parent,false);
        return new EmpChangeViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull EmpChangeViewHolder holder, int position) {
        final EmpChange change = changes.get(position);
        System.out.println(change);
        holder.tvEname.setText(change.getEmp().getEname());
        holder.tvOldDname.setText(change.getOldDept().getDname());
        holder.tvNewDname.setText(change.getNewDept().getDname());
        holder.tvOldJname.setText(change.getOldJob().getJname());
        holder.tvNewJname.setText(change.getNewJob().getJname());
        holder.tvReason.setText(change.getReason());
        if (change.getStatus()==EntityStatus.UNDEFINED.ordinal()){
            holder.tvStatus.setText("未处理！");
            holder.ibOn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder  builder = new AlertDialog.Builder(activity);
                    builder.setTitle("确认同意该申请吗?");
                    builder.setNegativeButton("确认", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            change.setStatus(EntityStatus.ON.ordinal());
                            Emp emp = change.getEmp();
                            emp.setDept(change.getNewDept());
                            emp.setJob(change.getNewJob());
                            empDao.update(emp);
                            dao.updateStatus(change);
                            notifyDataSetChanged();
                        }
                    });
                    builder.setPositiveButton("取消",null);
                    builder.show();
                }
            });
            holder.ibOff.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder  builder = new AlertDialog.Builder(activity);
                    builder.setTitle("确认拒绝该申请吗?");
                    builder.setNegativeButton("确认", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            change.setStatus(EntityStatus.OFF.ordinal());
                            dao.updateStatus(change);
                            notifyDataSetChanged();
                        }
                    });
                    builder.setPositiveButton("取消",null);
                    builder.show();
                }
            });
        }else if(change.getStatus()==EntityStatus.ON.ordinal()){
            holder.tvStatus.setText("同意");
            holder.ibOn.setVisibility(View.INVISIBLE);
            holder.ibOff.setVisibility(View.INVISIBLE);
        }else{
            holder.tvStatus.setText("拒绝");
            holder.ibOn.setVisibility(View.INVISIBLE);
            holder.ibOff.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    public int getItemCount() {
        return changes.size();
    }



    public class EmpChangeViewHolder extends RecyclerView.ViewHolder{

         TextView tvEname ,tvOldDname,tvNewDname, tvOldJname, tvNewJname, tvReason, tvStatus;
         ImageButton ibOn,ibOff;

        public EmpChangeViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEname =itemView.findViewById(R.id.tvEname);
            tvOldDname =itemView.findViewById(R.id.tvOldDname);
            tvNewDname =itemView.findViewById(R.id.tvNewDname);
            tvOldJname =itemView.findViewById(R.id.tvOldJname);
            tvNewJname =itemView.findViewById(R.id.tvNewJname);
            tvReason =itemView.findViewById(R.id.tvReason);
            tvStatus =itemView.findViewById(R.id.tvStatus);
            ibOn =itemView.findViewById(R.id.ibOn);
            ibOff =itemView.findViewById(R.id.ibOff);
        }
    }
}
