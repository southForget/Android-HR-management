package com.ms.duet.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ms.duet.dababase.DuetDataBase;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.EmpLeave;
import com.ms.duet.entity.Job;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EmpLeaveDao {
    private DuetDataBase database;

    public EmpLeaveDao(Context context) {
        this.database = new DuetDataBase(context,"iHr.db",null,1);
    }

    public void insert(EmpLeave leave) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("eid",leave.getEmp().getEid());
        values.put("did",leave.getDept().getDid());
        values.put("jid",leave.getJob().getJid());
        values.put("enterDate",leave.getEnterDate().getTime());
        values.put("leaveDate",leave.getLeaveDate().getTime());
        values.put("reason",leave.getReason());
        values.put("status", EntityStatus.UNDEFINED.ordinal());
        long row  =database.insert("empLeave",null,values);
    }

    public List<EmpLeave> findAll() {
        SQLiteDatabase database = this.database.getReadableDatabase();
        String[] cloumns = new String[]{
                "elid","el.eid","ename","el.did","dname","el.jid","jname","el.enterDate","leaveDate","reason","el.status"
        };
        Cursor cursor = database.query("empLeave el left join emp e on el.eid = e.eid left join dept d on el.did = d.did left join job j on el.jid = j.jid",cloumns,null,null,null,null,null);
        List<EmpLeave> leaves = new ArrayList<>();
        if (cursor!=null && cursor.getCount()>0){
            while (cursor.moveToNext()){
                int elid = cursor.getInt(cursor.getColumnIndex("elid"));
                int eid = cursor.getInt(cursor.getColumnIndex("eid"));
                String ename = cursor.getString(cursor.getColumnIndex("ename"));
                int did = cursor.getInt(cursor.getColumnIndex("did"));
                String dname = cursor.getString(cursor.getColumnIndex("dname"));
                int jid = cursor.getInt(cursor.getColumnIndex("jid"));
                String jname = cursor.getString(cursor.getColumnIndex("jname"));
                long enter =cursor.getLong(cursor.getColumnIndex("enterDate"));
                long leaved=cursor.getLong(cursor.getColumnIndex("leaveDate"));
                String reason = cursor.getString(cursor.getColumnIndex("reason"));
                int status =cursor.getInt(cursor.getColumnIndex("status"));
                EmpLeave leave= new EmpLeave();
                Emp emp = new Emp();
                Dept dept =new Dept();
                Job job = new Job();
                leave.setElid(elid);
                emp.setEid(eid);
                dept.setDid(did);
                dept.setDname(dname);
                job.setJid(jid);
                job.setJname(jname);
                emp.setEname(ename);
                leave.setEmp(emp);
                leave.setDept(dept);
                leave.setJob(job);
                leave.setEnterDate(new Date(enter));
                leave.setLeaveDate(new Date(leaved));
                leave.setReason(reason);
                leave.setStatus(status);
                leaves.add(leave);
            }
            cursor.close();
        }
        database.close();
        return leaves;
    }

    public void updateStatus(EmpLeave leave) {
        SQLiteDatabase database = this.database.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status",leave.getStatus());
        database.update("empLeave",values,"elid=?",new String[]{String.valueOf(leave.getElid())});
        database.close();
    }


}
