package com.ms.duet;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ms.duet.dao.JobDao;
import com.ms.duet.entity.Job;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateJobFragment extends Fragment {

    private JobDao dao;
    EditText etJname;
    EditText etJdes;
    Button btnUpdate;
    public UpdateJobFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_update_job, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        int jid =getArguments().getInt("jid");
        dao= new JobDao(requireActivity());
        final Job job =dao.findJobByjid(jid);
        etJname =getView().findViewById(R.id.etJname);
        etJdes=getView().findViewById(R.id.etJdes);
        btnUpdate=getView().findViewById(R.id.btnUpdate);
        etJname.setText(job.getJname());
        etJdes.setText(job.getJdes());
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String jname = etJname.getText().toString().trim();
                String jdes =etJdes.getText().toString().trim();
                if (TextUtils.isEmpty(jname)|| TextUtils.isEmpty(jdes)){
                    Toast.makeText(requireActivity(),"职位名称或职位描述不能为空！",Toast.LENGTH_SHORT).show();
                    return;
                }
                job.setJname(jname);
                job.setJdes(jdes);
                dao.update(job);
                Toast.makeText(requireActivity(),"修改成功！",Toast.LENGTH_SHORT).show();
                Navigation.findNavController(getActivity(),R.id.fragment).navigateUp();
            }
        });
    }
}
