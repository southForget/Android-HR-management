package com.ms.duet;


import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ms.duet.adapter.SpinnerDeptAdapter;
import com.ms.duet.adapter.SpinnerJobAdapter;
import com.ms.duet.dao.EmpChangeDao;
import com.ms.duet.dao.EmpDao;
import com.ms.duet.dao.EmpLeaveDao;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.EmpChange;
import com.ms.duet.entity.EmpLeave;
import com.ms.duet.entity.Job;
import com.ms.duet.entity.enumerate.EntityStatus;
import com.ms.duet.tool.Tool;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * A simple {@link Fragment} subclass.
 */
public class EmpFragment extends Fragment {
    int jid=-1;
    int did=-1;
    TextView tvJobnun,tvEname,tvDname,tvJname;
    ImageView ivGender;
    Button  btnUpdate,btnExit,btnTransfer;
    EditText etPhone,etEmail;
    Emp emp;
    EmpDao dao;
    public EmpFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_emp, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        View v =getView();
        final int eid=getArguments().getInt("eid");
        dao=new EmpDao(requireActivity());
        emp =dao.findEmpByEid(eid);
        tvJobnun=v.findViewById(R.id.tvJobnun);
        tvEname=v.findViewById(R.id.tvEname);
        tvDname=v.findViewById(R.id.tvDname);
        tvJname = v.findViewById(R.id.tvJname);
        ivGender=v.findViewById(R.id.ivGender);
        btnUpdate=v.findViewById(R.id.btnUpdate);
        btnExit=v.findViewById(R.id.btnExit);
        btnTransfer=v.findViewById(R.id.btnTransfer);
        tvJobnun.setText(emp.getJobNun());
        tvEname.setText(emp.getEname());
        tvDname.setText(emp.getDept().getDname());
        tvJname.setText(emp.getJob().getJname());
        if (emp.getGender()){
            ivGender.setImageResource(R.drawable.manavatar);
        }else{
            ivGender.setImageResource(R.drawable.womanavatar);
        }
        final View updateConcat = View.inflate(requireActivity(),R.layout.dialog_update_contact,null);
        etEmail=updateConcat.findViewById(R.id.etEmail);
        etPhone=updateConcat.findViewById(R.id.etPhone);
        etEmail.setText(emp.getEmail());
        etPhone.setText(emp.getPhone());
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
                builder.setTitle("修改联系方式");
                builder.setView(updateConcat);
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String email =etEmail.getText().toString().trim();
                        String phone =etPhone.getText().toString().trim();
                        if (TextUtils.isEmpty(email)){
                            Toast.makeText(requireActivity(),"邮箱不能为空",Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (TextUtils.isEmpty(phone)){
                            Toast.makeText(requireActivity(),"手机号码不能为空",Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (!Tool.checkEmail(email)){
                            Toast.makeText(requireActivity(),"邮箱格式不正确！",Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (!Tool.checkPhone(phone)){
                            Toast.makeText(requireActivity(),"手机号格式不正确！",Toast.LENGTH_SHORT).show();
                            return;
                        }
                        emp.setPhone(phone);
                        emp.setEmail(email);
                        dao.updateConcat(emp);
                        Toast.makeText(requireActivity(),"联系方式修改成功！",Toast.LENGTH_SHORT).show();
                        ((ViewGroup) updateConcat.getParent()).removeView(updateConcat);
                    }
                });
                builder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((ViewGroup) updateConcat.getParent()).removeView(updateConcat);
                    }
                });
                builder.show();
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText etReason;
                final TextView tvLeaveDate;
                final View leave = View.inflate(requireActivity(),R.layout.dialog_leave,null);
                etReason=leave.findViewById(R.id.etReason);
                tvLeaveDate=leave.findViewById(R.id.tvLeaveDate);
                tvLeaveDate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Calendar calendar =Calendar.getInstance();
                        int year= calendar.get(Calendar.YEAR);
                        int month=calendar.get(Calendar.MONTH);
                        int day=calendar.get(Calendar.DAY_OF_MONTH);
                        DatePickerDialog dpd= new DatePickerDialog(requireContext(),DatePickerDialog.THEME_DEVICE_DEFAULT_LIGHT,
                                new DatePickerDialog.OnDateSetListener(){
                                    @Override
                                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                        tvLeaveDate.setText(year+"-"+(monthOfYear+1)+"-"+dayOfMonth);
                                    }
                                },year,month,day);
                        dpd.show();
                    }
                });
                AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
                builder.setTitle("申请离职");
                builder.setView(leave);
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String date = tvLeaveDate.getText().toString().trim();
                        String reason = etReason.getText().toString().trim();
                        if (TextUtils.isEmpty(date)) {
                            Toast.makeText(requireActivity(), "日期不能为空", Toast.LENGTH_SHORT).show();
                            return;
                        }else if (TextUtils.isEmpty(reason)) {
                            Toast.makeText(requireActivity(), "离职理由不能为空", Toast.LENGTH_SHORT).show();
                            return;
                        }else {
                            EmpLeaveDao leaveDao = new EmpLeaveDao(requireActivity());
                            EmpLeave leave1 = new EmpLeave();
                            leave1.setEmp(emp);
                            leave1.setDept(emp.getDept());
                            leave1.setJob(emp.getJob());
                            leave1.setReason(reason);
                            leave1.setEnterDate(emp.getEnterDate());
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                            Date now = new Date();
                            try {
                                Date leaveDate = sdf.parse(date);
                                if (leaveDate.compareTo(now) == -1) {
                                    Toast.makeText(requireActivity(), "离职日期应大于今天", Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                leave1.setLeaveDate(leaveDate);
                            } catch (ParseException e) {
                                Toast.makeText(requireActivity(), "时间格式不正确！", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            leaveDao.insert(leave1);
                            Toast.makeText(requireActivity(), "申请成功，请等待后台审核！", Toast.LENGTH_SHORT).show();
                            ((ViewGroup) leave.getParent()).removeView(leave);
                        }
                    }
                }).setPositiveButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((ViewGroup) leave.getParent()).removeView(leave);
                    }
                });
                builder.show();
            }
        });


        btnTransfer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tvDname,tvJname;
                Spinner spDept,spJob;
                final SpinnerDeptAdapter deptAdapter = new SpinnerDeptAdapter(requireActivity());
                final SpinnerJobAdapter jobAdapter = new SpinnerJobAdapter(requireActivity());
                final EditText etReason;
                final View transfer = View.inflate(requireActivity(),R.layout.dialog_change,null);
                tvDname=transfer.findViewById(R.id.tvDname);
                tvJname=transfer.findViewById(R.id.tvJname);
                spDept=transfer.findViewById(R.id.spDept);
                spJob=transfer.findViewById(R.id.spJob);
                etReason=transfer.findViewById(R.id.etReason);
                int dp =deptAdapter.getPositionById(emp.getDept().getDid());
                int jp =jobAdapter.getPositionById(emp.getJob().getJid());
                did=emp.getDept().getDid();
                jid=emp.getJob().getJid();
                tvDname.setText(emp.getDept().getDname());
                tvJname.setText(emp.getJob().getJname());
                spDept.setAdapter(deptAdapter);
                spJob.setAdapter(jobAdapter);
                spDept.setSelection(dp,true);
                spJob.setSelection(jp,true);
                spDept.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        did= (int) deptAdapter.getItemId(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        did=0;
                    }

                });
                spJob.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        jid= (int) jobAdapter.getItemId(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        jid=0;
                    }
                });

                AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
                builder.setTitle("申请调动");
                builder.setView(transfer);
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String reason = etReason.getText().toString().trim();
                        if (TextUtils.isEmpty(reason)){
                            Toast.makeText(requireContext(),"申请理由不能为空！",Toast.LENGTH_SHORT).show();
                            return;
                        }else if (emp.getDept().getDid()==did&&emp.getJob().getJid()==jid){
                            Toast.makeText(requireContext(),"错误的操作，不予执行！",Toast.LENGTH_SHORT).show();
                            return;
                        }else{
                            EmpChange change = new EmpChange();
                            EmpChangeDao changeDao=new EmpChangeDao(requireActivity());
                            change.setOldDept(emp.getDept());
                            change.setOldJob(emp.getJob());
                            change.setEmp(emp);
                            Dept newDept  = new Dept();
                            newDept.setDid(did);
                            Job nweJob = new Job();
                            nweJob.setJid(jid);
                            change.setNewDept(newDept);
                            change.setNewJob(nweJob);
                            change.setReason(reason);
                            change.setStatus(EntityStatus.UNDEFINED.ordinal());
                            changeDao.insert(change);
                            Toast.makeText(requireContext(),"申请成功，请等待后台审核！",Toast.LENGTH_SHORT).show();
                        }
                        ((ViewGroup) transfer.getParent()).removeView(transfer);
                    }
                });
                builder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ((ViewGroup) transfer.getParent()).removeView(transfer);
                    }
                });
                builder.show();

            }
        });
    }
}
