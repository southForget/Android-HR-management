package com.ms.duet.entity.enumerate;

public enum EntityStatus {
    ON(1),OFF(2),INIT(3),STOP(4),UNDEFINED(5),RESETPASSWORD(6);

    EntityStatus(int i) {

    }
}
