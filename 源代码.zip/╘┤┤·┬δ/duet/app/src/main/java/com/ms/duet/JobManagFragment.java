package com.ms.duet;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ms.duet.adapter.JobAdapter;
import com.ms.duet.entity.Job;
import com.ms.duet.entity.enumerate.EntityStatus;


/**
 * A simple {@link Fragment} subclass.
 */
public class JobManagFragment extends Fragment {
    RecyclerView rcJob;
    JobAdapter adapter;
    Button btnAdd,btnRest;
    EditText etJname,etJdes;

    public JobManagFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_job_manag, container, false);
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rcJob = view.findViewById(R.id.rvJob);
        btnAdd=view.findViewById(R.id.btnAddEmp);
        btnRest=view.findViewById(R.id.btnRest);
        etJname = view.findViewById(R.id.etJname);
        etJdes=view.findViewById(R.id.etJdes);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String jname = etJname.getText().toString().trim();
                String jdes =etJdes.getText().toString().trim();
                if(TextUtils.isEmpty(jname) || TextUtils.isEmpty(jdes)){
                    Toast.makeText(requireContext(),"职位名称或职位描述不能为空！",Toast.LENGTH_SHORT).show();
                    return;
                }
                Job job = new Job();
                job.setJname(jname);
                job.setJdes(jdes);
                job.setStatus(EntityStatus.ON.ordinal());
                adapter.insert(job);
                etJname.setText("");
                etJdes.setText("");
            }
        });

        btnRest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etJname.setText("");
                etJdes.setText("");;
            }
        });
        adapter = new JobAdapter(requireActivity());
        rcJob.setLayoutManager(new LinearLayoutManager(getContext()));
        rcJob.setAdapter(adapter);
    }
}
