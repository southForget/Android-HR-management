package com.ms.duet.entity;



public class EmpChange {
    private int ecid;
    private Emp emp;
    private Dept oldDept;
    private Dept newDept;
    private Job oldJob;
    private Job newJob;
    private String reason;
    private int status;


    public int getEcid() {
        return ecid;
    }

    public void setEcid(int ecid) {
        this.ecid = ecid;
    }

    public Emp getEmp() {
        return emp;
    }

    public void setEmp(Emp emp) {
        this.emp = emp;
    }

    public Dept getOldDept() {
        return oldDept;
    }

    public void setOldDept(Dept oldDept) {
        this.oldDept = oldDept;
    }

    public Dept getNewDept() {
        return newDept;
    }

    public void setNewDept(Dept newDept) {
        this.newDept = newDept;
    }

    public Job getOldJob() {
        return oldJob;
    }

    public void setOldJob(Job oldJob) {
        this.oldJob = oldJob;
    }

    public Job getNewJob() {
        return newJob;
    }

    public void setNewJob(Job newJob) {
        this.newJob = newJob;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "EmpChange{" +
                "ecid=" + ecid +
                ", emp=" + emp +
                ", oldDept=" + oldDept +
                ", newDept=" + newDept +
                ", oldJob=" + oldJob +
                ", newJob=" + newJob +
                ", reason='" + reason + '\'' +
                ", status=" + status +
                '}';
    }
}

