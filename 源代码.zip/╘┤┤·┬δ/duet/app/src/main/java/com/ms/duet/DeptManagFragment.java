package com.ms.duet;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ms.duet.adapter.DeptAdapter;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.enumerate.EntityStatus;

/**
 * A simple {@link Fragment} subclass.
 */
public class DeptManagFragment extends Fragment {

    RecyclerView rcDept;
    DeptAdapter adapter;
    Button btnAdd,btnRest;
    EditText etDname,etDdes;
    public DeptManagFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_dept_manag, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rcDept = view.findViewById(R.id.rvJob);
        btnAdd=view.findViewById(R.id.btnAddEmp);
        btnRest=view.findViewById(R.id.btnRest);
        etDname = view.findViewById(R.id.etDname);
        etDdes=view.findViewById(R.id.etDdes);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dname = etDname.getText().toString().trim();
                String ddes =etDdes.getText().toString().trim();
                if(TextUtils.isEmpty(dname) || TextUtils.isEmpty(ddes)){
                    Toast.makeText(requireContext(),"部门名称或部门描述不能为空！",Toast.LENGTH_SHORT).show();
                    return;
                }
                Dept dept= new Dept();
                dept.setDname(dname);
                dept.setDdes(ddes);
                dept.setStatus(EntityStatus.ON.ordinal());
                adapter.insert(dept);
                etDname.setText("");
                etDdes.setText("");
            }
        });

        btnRest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etDname.setText("");
                etDdes.setText("");
            }
        });
        adapter = new DeptAdapter(requireActivity());
        rcDept.setLayoutManager(new LinearLayoutManager(getContext()));
        rcDept.setAdapter(adapter);
    }
}
