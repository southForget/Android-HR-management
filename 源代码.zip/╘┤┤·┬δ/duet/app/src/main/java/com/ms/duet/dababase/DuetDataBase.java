package com.ms.duet.dababase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DuetDataBase extends SQLiteOpenHelper {
    public DuetDataBase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table admin( aid INTEGER not null PRIMARY key,account TEXT not null,password text not null)");
        db.execSQL("create table dept(did integer not null primary key,dname text not null ,ddes text not null,status integer not null)");
        db.execSQL("create table job(jid integer not null primary key,jname text not null ,jdes text not null,status integer)");
        db.execSQL("create table emp( eid integer primary key,jobNun text not null UNIQUE ,password text not null,did integer not null, jid integer not null,enterDate NUMERIC not null,salary REAL not null,ename text not null,gender integer not null,birth numeric not null, phone text ,email text ,status integer not null,foreign key (did) references dept(did),foreign key (jid) references job(jid))");
        db.execSQL("create table empLeave(elid integer not null primary key,eid integer not null ,did integer not null,jid not null,enterDate NUMERIC not null,leaveDate NUMERIC not null ,reason text not null, status inetger not null,foreign key (did) references dept(did),foreign key (jid) references job(jid),foreign key(eid) references emp(eid))");
        db.execSQL("create table empChange(ecid integer not null primary key,eid integer not null ,oldDid integer not null,newDid integer not null,oldJid integer not null,newJid integer not null,reason text not null,status integer not null,foreign key(oldDid) references dept(did),foreign key(newDid) references dept(did),foreign key(oldJid) references job(jid),foreign key(newJid) references job(jid),foreign key(eid) references emp(eid))");
        db.execSQL("insert into admin( account,password) values('admin','admin')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
