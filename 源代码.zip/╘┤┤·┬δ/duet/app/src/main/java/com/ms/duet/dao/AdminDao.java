package com.ms.duet.dao;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.ms.duet.dababase.DuetDataBase;
import com.ms.duet.entity.Admin;

public class AdminDao {
    private DuetDataBase database;

    public AdminDao(Context context) {
        this.database = new DuetDataBase(context,"iHr.db",null,1);
    }

    public Admin login(Admin admin){
        SQLiteDatabase database = this.database.getReadableDatabase();
        Cursor cursor = database.query("admin", new String[]{"aid"}, "account = ? and password =?", new String[]{admin.getAccount(), admin.getPassword()}, null, null, null);
        if (cursor!=null && cursor.getCount()==1){
            if (cursor.moveToNext()){
                admin.setAid(cursor.getInt(cursor.getColumnIndex("aid")));
            }
        }
        return  admin;
    }
}
