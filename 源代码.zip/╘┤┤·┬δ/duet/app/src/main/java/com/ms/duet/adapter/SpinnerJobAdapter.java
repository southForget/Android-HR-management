package com.ms.duet.adapter;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.ms.duet.R;
import com.ms.duet.dao.JobDao;
import com.ms.duet.entity.Job;

import java.util.List;

public class SpinnerJobAdapter extends BaseAdapter {
    Activity  activity;
    JobDao dao;
    List<Job> jobs;

    public SpinnerJobAdapter(Activity activity) {
        this.activity = activity;
        dao=new JobDao(activity);
        jobs=dao.findAllByStatusOn();
    }

    public int getPositionById(int id){
        Object[] objects = jobs.toArray();
        for (int i = 0; i <objects.length ; i++) {
            Job item = (Job) objects[i];
            if (item.getJid()==id)
                return i;
        }
        return 0;
    }

    @Override
    public int getCount() {
        return jobs.size();
    }

    @Override
    public Object getItem(int position) {
        return jobs.get(position);
    }

    @Override
    public long getItemId(int position) {
        return jobs.get(position).getJid();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = convertView!=null?convertView:View.inflate(activity, R.layout.cell_spinner_item,null);
        Job job = (Job) getItem(position);
        TextView textView = convertView.findViewById(R.id.tvSpItem);
        textView.setText(job.getJname());
        return convertView;
    }
}
