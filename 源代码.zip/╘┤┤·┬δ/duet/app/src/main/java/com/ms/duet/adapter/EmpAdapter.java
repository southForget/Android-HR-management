package com.ms.duet.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.ms.duet.R;
import com.ms.duet.dao.EmpDao;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.List;

public class EmpAdapter extends RecyclerView.Adapter<EmpAdapter.EmpViewHolder> {

    private Activity activity;
    private List<Emp> emps;
    private NavController controller;
    private EmpDao dao;
    public EmpAdapter(Activity activity) {
        this.activity = activity;
        dao = new EmpDao(activity);
        emps=dao.findAll("");
        controller = Navigation.findNavController(activity,R.id.fragment);
    }


    @NonNull
    @Override
    public  EmpViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(parent.getContext());
        View itemView =inflater.inflate(R.layout.cell_card_emp,parent,false);
        return new EmpViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull EmpViewHolder holder, int position) {
        final Emp emp = emps.get(position);
        holder.tvJobnun.setText(emp.getJobNun());
        holder.tvEname.setText(emp.getEname());
        if (emp.getGender()){
            holder.tvGender.setText("男");
        }else{
            holder.tvGender.setText("女");
        }
        holder.tvDept.setText(emp.getDept().getDname());
        holder.tvJob.setText(emp.getJob().getJname());
        holder.tvSalary.setText(String.valueOf(emp.getSalary()));
        String enter =emp.getEnterDate().toLocaleString();
        holder.tvEnterdate.setText(enter.substring(0,enter.lastIndexOf("日")+1));
        String birth =emp.getBirth().toLocaleString();
        holder.tvBirth.setText(birth.substring(0,birth.lastIndexOf("日")+1));
        holder.tvPhone.setText(emp.getPhone());
        holder.tvEmail.setText(emp.getEmail());
        if (emp.getStatus()==EntityStatus.ON.ordinal()||emp.getStatus()==EntityStatus.RESETPASSWORD.ordinal()){
            holder.tvStatus.setText("在职");
        }else if (emp.getStatus()==EntityStatus.OFF.ordinal()){
            holder.tvStatus.setText("离职");
            holder.ibLeave.setVisibility(View.INVISIBLE);
            holder.ibResetpassword.setVisibility(View.INVISIBLE);
        }
        holder.ibLeave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("确定要离职该员工吗？该操作不可撤销！");
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        emp.setStatus(EntityStatus.OFF.ordinal());
                        dao.update(emp);
                    }
                });
                builder.setPositiveButton("取消",null);
                builder.show();
            }
        });
        holder.ibResetpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("确定要重置该员工密码吗？该操作不可撤销！");
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dao.resetPassword(emp);
                        Toast.makeText(activity,"密码重置为：123456",Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setPositiveButton("取消",null);
                builder.show();
            }
        });
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (emp.getStatus()==EntityStatus.OFF.ordinal()){
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putInt("eid",emp.getEid());
                controller.navigate(R.id.action_empManagFragment_to_updateEmpFragment,bundle);
            }
        });
    }

    public void serachKey(String key){
        emps=dao.findAll(key);
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return emps.size();
    }



    public class EmpViewHolder extends RecyclerView.ViewHolder{
        TextView tvJobnun,tvEname,tvGender,tvDept,tvJob,tvSalary,tvEnterdate,tvBirth,tvPhone,tvEmail,tvStatus;
        ImageButton ibLeave,ibResetpassword;
        public EmpViewHolder(@NonNull View itemView) {
            super(itemView);
            tvJobnun=itemView.findViewById(R.id.tvJobnun);
            tvEname=itemView.findViewById(R.id.tvEname);
            tvGender=itemView.findViewById(R.id.tvGender);
            tvDept=itemView.findViewById(R.id.tvDept);
            tvJob=itemView.findViewById(R.id.tvJob);
            tvSalary=itemView.findViewById(R.id.tvSalary);
            tvEnterdate=itemView.findViewById(R.id.tvEnterdate);
            tvBirth=itemView.findViewById(R.id.tvBirth);
            tvPhone=itemView.findViewById(R.id.tvPhone);
            tvEmail=itemView.findViewById(R.id.tvEmail);
            tvStatus=itemView.findViewById(R.id.tvStatus);
            ibLeave=itemView.findViewById(R.id.ibLeave);
            ibResetpassword=itemView.findViewById(R.id.ibResetPassword);
        }
    }
}
