package com.ms.duet.entity;


import java.util.Date;

public class Emp {
    private int eid;
    private String jobNun;
    private String password;
    private Dept dept;
    private Job job;
    private Date enterDate;
    private float salary;
    private String  ename;
    private boolean gender;
    private Date birth;
    private String phone;
    private String email;
    private int status;


    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String getJobNun() {
        return jobNun;
    }

    public void setJobNun(String jobNun) {
        this.jobNun = jobNun;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Dept getDept() {
        return dept;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public Date getEnterDate() {
        return enterDate;
    }

    public void setEnterDate(Date enterDate) {
        this.enterDate = enterDate;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public boolean getGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public Date getBirth() {
        return birth;
    }

    public void setBirth(Date birth) {
        this.birth = birth;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Emp{" +
                "eid=" + eid +
                ", jobNun='" + jobNun + '\'' +
                ", password='" + password + '\'' +
                ", dept=" + dept +
                ", job=" + job +
                ", enterDate=" + enterDate +
                ", salary=" + salary +
                ", ename='" + ename + '\'' +
                ", gender=" + gender +
                ", birth=" + birth +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", status=" + status +
                '}';
    }
}
