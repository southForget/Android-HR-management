package com.ms.duet.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.ms.duet.R;
import com.ms.duet.dao.DeptDao;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.List;

public class DeptAdapter extends RecyclerView.Adapter<DeptAdapter.DeptViewHolder> {

    private Activity activity;
    private List<Dept> depts;
    private NavController controller;
    private DeptDao dao;
    public DeptAdapter(Activity activity) {
        this.activity = activity;
        dao = new DeptDao(activity);
        depts=dao.findAll();
        controller = Navigation.findNavController(activity,R.id.fragment);
    }

    public void insert(Dept dept) {
        Dept result = dao.isExitByDname(dept);
        if (result.getStatus()==EntityStatus.UNDEFINED.ordinal()){
            dao.insert(dept);
            depts.add(dept);
            notifyDataSetChanged();
        }else if(result.getStatus()==EntityStatus.ON.ordinal()){
            Toast.makeText(activity,"该部门已存在，且未删除！不能重复添加！",Toast.LENGTH_SHORT).show();
        }else if(result.getStatus()==EntityStatus.OFF.ordinal()){
            result.setStatus(EntityStatus.ON.ordinal());
            dao.update(result);
            Dept inlist= getDeptFromListByDid(result.getDid());
            if (inlist==null){
                return;
            }
            inlist.setStatus(EntityStatus.ON.ordinal());
            notifyDataSetChanged();
            Toast.makeText(activity,"该部门已存在但已被删除！现已启用！",Toast.LENGTH_SHORT).show();
        }
    }

    private Dept getDeptFromListByDid(int did){
        for (Dept item: depts) {
            if (item.getDid()==did){
                return item;
            }
        }
        return null;
    }
    @NonNull
    @Override
    public  DeptViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(parent.getContext());
        View itemView =inflater.inflate(R.layout.cell_card_dept_u_job,parent,false);
        return new DeptViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull DeptViewHolder holder, int position) {
        final Dept dept = depts.get(position);
        View.OnClickListener off  = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dao.getCountByDid(dept.getDid())>0){
                    Toast.makeText(activity,"该部门下存在员工不能删除！",Toast.LENGTH_SHORT).show();
                    return;
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("你确定要删除该部门吗？");
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dept.setStatus(EntityStatus.OFF.ordinal());
                        dao.update(dept);
                        notifyDataSetChanged();
                    }
                });
                builder.setPositiveButton("取消",null);
                builder.show();
            }
        };
        View.OnClickListener on  = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("你确定要重启该部门吗？");
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dept.setStatus(EntityStatus.ON.ordinal());
                        dao.update(dept);
                        notifyDataSetChanged();
                    }
                });
                builder.setPositiveButton("取消",null);
                builder.show();
            }
        };

        holder.tvId.setText(String.valueOf(dept.getDid()));
        holder.tvName.setText(dept.getDname());
        holder.tvDes.setText(dept.getDdes());
        if (dept.getStatus() == EntityStatus.ON.ordinal()){
            holder.tvStatus.setText("启用");
            holder.ibtnDel.setOnClickListener(off);
            holder.ibtnDel.setImageResource(R.drawable.ic_delete_black_24dp);
        }else if (dept.getStatus() == EntityStatus.OFF.ordinal()){
            holder.tvStatus.setText("停用");
            holder.ibtnDel.setOnClickListener(on);
            holder.ibtnDel.setImageResource(R.drawable.ic_refresh_black_24dp);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle( );
                bundle.putInt("did",dept.getDid());
                controller.navigate(R.id.action_deptManagFragment_to_updateDeptFragment,bundle);
            }
        });
    }

    @Override
    public int getItemCount() {
        return depts.size();
    }

    public class DeptViewHolder extends RecyclerView.ViewHolder{
        TextView tvId,tvName,tvDes,tvStatus;
        ImageButton ibtnDel;
        public DeptViewHolder(@NonNull View itemView) {
            super(itemView);
            tvId=itemView.findViewById(R.id.tvId);
            tvName=itemView.findViewById(R.id.tvName);
            tvDes =itemView.findViewById(R.id.tvDes);
            tvStatus=itemView.findViewById(R.id.tvStatus);
            ibtnDel=itemView.findViewById(R.id.ibtnDel);
        }
    }
}
