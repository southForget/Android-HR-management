package com.ms.duet.adapter;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.ms.duet.R;
import com.ms.duet.dao.JobDao;
import com.ms.duet.entity.Dept;
import com.ms.duet.entity.Job;
import com.ms.duet.entity.enumerate.EntityStatus;

import java.util.List;

public class JobAdapter extends RecyclerView.Adapter<JobAdapter.JobViewHolder> {

    private Activity activity;
    private List<Job> jobs;
    private NavController controller;
    private JobDao dao;
    public JobAdapter(Activity activity) {
        this.activity = activity;
        dao = new JobDao(activity);
        jobs=dao.findAll();
        controller = Navigation.findNavController(activity,R.id.fragment);
    }

    public void insert(Job job) {
        Job result = dao.isExitByJname(job);
        if (result.getStatus()==EntityStatus.UNDEFINED.ordinal()){
            dao.insert(job);
            jobs.add(job);
            notifyDataSetChanged();
        }else if(result.getStatus()==EntityStatus.ON.ordinal()){
            Toast.makeText(activity,"该职位已存在，且未删除！不能重复添加！",Toast.LENGTH_SHORT).show();
        }else if(result.getStatus()==EntityStatus.OFF.ordinal()){
            result.setStatus(EntityStatus.ON.ordinal());
            dao.update(result);
            Job inlist= getJobFromListByJid(result.getJid());
            if (inlist==null){
                return;
            }
            inlist.setStatus(EntityStatus.ON.ordinal());
            notifyDataSetChanged();
            Toast.makeText(activity,"该部门已存在但已被删除！现已启用！",Toast.LENGTH_SHORT).show();
        }
    }

    private Job getJobFromListByJid(int jid){
        for (Job item: jobs) {
            if (item.getJid()==jid){
                return item;
            }
        }
        return null;
    }
    @NonNull
    @Override
    public  JobViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(parent.getContext());
        View itemView =inflater.inflate(R.layout.cell_card_dept_u_job,parent,false);
        return new JobViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull JobViewHolder holder, int position) {
        final Job job = jobs.get(position);
        View.OnClickListener off  = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dao.getCountByJid(job.getJid())>0){
                    Toast.makeText(activity,"该职位下存在员工不能删除！",Toast.LENGTH_SHORT).show();
                    return;
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("你确定要删除该职位吗？");
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        job.setStatus(EntityStatus.OFF.ordinal());
                        dao.update(job);
                        notifyDataSetChanged();
                    }
                });
                builder.setPositiveButton("取消",null);
                builder.show();
            }
        };
        View.OnClickListener on  = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("你确定要重启该职位吗？");
                builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        job.setStatus(EntityStatus.ON.ordinal());
                        dao.update(job);
                        notifyDataSetChanged();
                    }
                });
                builder.setPositiveButton("取消",null);
                builder.show();
            }
        };

        holder.tvId.setText(String.valueOf(job.getJid()));
        holder.tvName.setText(job.getJname());
        holder.tvDes.setText(job.getJdes());
        if (job.getStatus() == EntityStatus.ON.ordinal()){
            holder.tvStatus.setText("启用");
            holder.ibtnDel.setOnClickListener(off);
            holder.ibtnDel.setImageResource(R.drawable.ic_delete_black_24dp);
        }else if (job.getStatus() == EntityStatus.OFF.ordinal()){
            holder.tvStatus.setText("停用");
            holder.ibtnDel.setOnClickListener(on);
            holder.ibtnDel.setImageResource(R.drawable.ic_refresh_black_24dp);
        }
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle bundle = new Bundle( );
                bundle.putInt("jid",job.getJid());
                controller.navigate(R.id.action_jobManagFragment_to_updateJobFragment,bundle);
            }
        });
    }

    @Override
    public int getItemCount() {
        return jobs.size();
    }



    public class JobViewHolder extends RecyclerView.ViewHolder{
        TextView tvId,tvName,tvDes,tvStatus;
        ImageButton ibtnDel;
        public JobViewHolder(@NonNull View itemView) {
            super(itemView);
            tvId=itemView.findViewById(R.id.tvId);
            tvName=itemView.findViewById(R.id.tvName);
            tvDes =itemView.findViewById(R.id.tvDes);
            tvStatus=itemView.findViewById(R.id.tvStatus);
            ibtnDel=itemView.findViewById(R.id.ibtnDel);
        }
    }
}
