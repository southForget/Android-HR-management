package com.ms.duet;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SearchView;

import com.ms.duet.adapter.EmpAdapter;
import com.ms.duet.entity.Emp;


/**
 * A simple {@link Fragment} subclass.
 */
public class EmpManagFragment extends Fragment {
    SearchView searchView;
    Button btnAdd;
    EmpAdapter adapter;
    RecyclerView recyclerView;
    SearchView searchBox;
    NavController controller;
    public EmpManagFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_emp_manag, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        searchView = getView().findViewById(R.id.searchBox);
        btnAdd=getView().findViewById(R.id.btnAddEmp);
        recyclerView=getView().findViewById(R.id.rcEmp);
        controller = Navigation.findNavController(getActivity(),R.id.fragment);
        adapter= new EmpAdapter(requireActivity());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controller.navigate(R.id.action_empManagFragment_to_addEmpFragment);
            }
        });
        searchBox = getView().findViewById(R.id.searchBox);
        searchBox.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                                             @Override
                                             public boolean onQueryTextSubmit(String query) {
                                                 adapter.serachKey(query);
                                                 return false;
                                             }

                                             @Override
                                             public boolean onQueryTextChange(String newText) {
                                                 adapter.serachKey(newText);
                                                 return false;
                                             }
                                         }
        );
    }
}
