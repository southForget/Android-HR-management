package com.ms.duet;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.ms.duet.dao.EmpDao;
import com.ms.duet.entity.Emp;
import com.ms.duet.entity.enumerate.EntityStatus;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateEmpPasswordFragment extends Fragment {
    TextView tvJobNun;
    EditText etPwd,etCheckpwd;
    Button button;
    EmpDao dao;
    public UpdateEmpPasswordFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_update_emp_password, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        dao= new EmpDao(requireActivity());
        View v = getView();
        tvJobNun = v.findViewById(R.id.tvJobNunInUpdate);
        etPwd = v.findViewById(R.id.etPwd);
        etCheckpwd = v.findViewById(R.id.etCheckpwd);
        button = v.findViewById(R.id.btnResetPassword);
        int eid = getArguments().getInt("eid");
        final Emp emp= dao.findEmpByEid(eid);
        tvJobNun.setText("工号："+emp.getJobNun());
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pwd1 = etPwd.getText().toString().trim();
                String pwd2 = etCheckpwd.getText().toString().trim();
                if (TextUtils.isEmpty(pwd1)||TextUtils.isEmpty(pwd2)){
                    Toast.makeText(requireContext(),"密码或确认密码不能为空！",Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!pwd1.equals(pwd2)){
                    Toast.makeText(requireContext(),"密码与确认密码不一致！",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(pwd1.length()<11){
                    Toast.makeText(requireContext(),"密码长度应大于10位！",Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!checkPassword(pwd1)){
                    Toast.makeText(requireContext(),"密码强度不足，应包含数字、字母、字符等！",Toast.LENGTH_SHORT).show();
                    return;
                }
                emp.setPassword(pwd1);
                emp.setStatus(EntityStatus.ON.ordinal());
                dao.updatePassword(emp);
                NavController controller = Navigation.findNavController(requireActivity(),R.id.fragment);
                Toast.makeText(requireContext(),"密码修改成功，请重新登录！",Toast.LENGTH_SHORT).show();
                controller.navigateUp();
            }
        });
    }

    public boolean checkPassword(String passwordStr) {
        String regexZ = "\\d*";
        String regexS = "[a-zA-Z]+";
        String regexT = "\\W+$";
        String regexZT = "\\D*";
        String regexST = "[\\d\\W]*";
        String regexZS = "\\w*";
        String regexZST = "[\\w\\W]*";

        if (passwordStr.matches(regexZ)) {
            return false;
        }
        if (passwordStr.matches(regexS)) {
            return false;
        }
        if (passwordStr.matches(regexT)) {
            return true;
        }
        if (passwordStr.matches(regexZT)) {
            return true;
        }
        if (passwordStr.matches(regexST)) {
            return true;
        }
        if (passwordStr.matches(regexZS)) {
            return true;
        }
        if (passwordStr.matches(regexZST)) {
            return true;
        }
        return false;

    }
}
